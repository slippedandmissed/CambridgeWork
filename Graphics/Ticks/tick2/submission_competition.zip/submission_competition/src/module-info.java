module tick2 {
	exports uk.ac.cam.cl.gfxintro.jbs52.tick2;

	requires java.desktop;
	requires joml;
	requires lwjgl;
}